# Application d’affichage TV des emplois du temps — UDL-SBA

Cette application propose :
- le téléversement d’un fichier Excel d’emploi du temps ;
- les filtres par jour, un ou plusieurs créneaux, promotion et département ;
- une prévisualisation web en liste défilante ou en grille ;
- l’export d’un fichier `EDT_TV_USB.html` autonome avec l’ensemble des lignes du classeur ;
- une horloge, un bouton pause/reprise, le réglage de vitesse et le plein écran.

## Lancement sur Windows

1. Installez Python 3.10 ou plus récent.
2. Ouvrez un terminal dans ce dossier.
3. Lancez :
   ```bash
   pip install -r requirements.txt
   streamlit run app_edt_tv.py
   ```
4. Ouvrez l’adresse locale affichée par Streamlit.
5. Téléversez un autre fichier Excel ou utilisez l’exemple fourni.

Un fichier Excel doit contenir au minimum les colonnes `Enseignements`, `Horaire`, `Jours` et `Promotion`. Les colonnes `Code`, `Enseignants`, `Lieu` et `Département` sont affichées si elles sont présentes ; les colonnes facultatives absentes sont laissées vides.

## Mode TV via lien web

Le code est prêt à déployer avec Streamlit Community Cloud :
1. Téléversez `app_edt_tv.py`, `requirements.txt` et éventuellement le fichier Excel d’exemple dans un dépôt GitHub.
2. Créez une application Streamlit à partir de ce dépôt, avec `app_edt_tv.py` comme fichier principal.
3. Utilisez le lien web fourni par la plateforme sur le navigateur de la TV ou sur un ordinateur relié à la TV.
4. Sélectionnez jour/créneaux/promotion, cliquez sur **Afficher / actualiser la TV**, puis mettez le navigateur en plein écran (F11).

Le lien web n’est pas hébergé automatiquement par la génération de ce pack : il faut déployer l’application sur un hébergeur accessible.

## Mode USB sans Internet

Le fichier `EDT_TV_USB.html` dans ce dossier est déjà prêt pour le classeur d’exemple joint :
1. Copiez ce fichier sur une clé USB.
2. Branchez la clé à un ordinateur ou à un téléviseur dont le navigateur sait ouvrir les fichiers HTML locaux.
3. Ouvrez `EDT_TV_USB.html`.
4. Choisissez jour, créneau, promotion et département directement dans le fichier, puis utilisez le défilement et le plein écran.

Pour un nouveau fichier Excel :
1. Lancez l’application web.
2. Téléversez le nouvel Excel.
3. Cliquez sur **Télécharger le fichier HTML autonome pour clé USB**.
4. Copiez le HTML obtenu sur la clé USB.

Le HTML est autonome et ne charge aucune bibliothèque externe. Si un téléviseur ne permet pas d’ouvrir un HTML local, utilisez un ordinateur ou mini-PC relié en HDMI.

## Important
Le classeur source n’est pas modifié. Les valeurs sont affichées comme elles figurent dans le fichier (après nettoyage des espaces dans les libellés horaires).
